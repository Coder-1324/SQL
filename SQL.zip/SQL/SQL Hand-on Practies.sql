use mydb;
create table customer (
 Customer_Id INT  primary key AUTO_INCREMENT,
 First_Name varchar(40),
 Last_Name varchar(50),
 email varchar(40),
 phone varchar(20),
 address varchar(30),
 City varchar(30)
 
 
);
insert into customer (Customer_Id,First_Name,Last_Name,email,phone,address,City)
values("Nikhil","Chopde","abc@gamil.com","1245477","Pune"),
("shubham","singh","sbm@gamil.com","23425477","mub"),
("Sachin","tendulkar","goa@gamil.com","17665477","goa"),
("virat","Kohli","dlyc@gamil.com","65434477","dehli"),
("rahul","jain","blr@gamil.com","67445477","BLR");


CREATE TABLE employees (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20),
    hire_date DATE,
    salary DECIMAL(10, 2),
    department_id INT
);

INSERT INTO employees (first_name, last_name, email, phone, hire_date, salary, department_id)
VALUES 
    ('virat', 'kohli', 'vk@example.com', '123-456-7890', '2020-01-15', 50000.00, 1),
    ('sachin', 'td', 'st@example.com', '234-567-8901', '2019-08-20', 60000.00, 2),
    ('rohit', 'sharma', 'rd@example.com', '345-678-9012', '2021-03-10', 55000.00, 3),
    ('jaspreet', 'boom', 'jb@example.com', '456-789-0123', '2022-02-05', 65000.00, 4),
    ('MD', 'Brown', 'mb@example.com', '567-890-1234', '2020-11-30', 70000.00, 5);

create table departments( department_id int  primary key,
 department_name varchar(50) unique
);
alter table employees
add constraint fk_department_id
foreign key (department_id) references
departments(department_id);

insert into departments(department_name)

/*Write a query to retrieve the names and email addresses of all employees. */
select first_name, last_name,email from employees;


/*Write a query to find the total number of employees in each department.*/
SELECT department_id, count(*) as total_employees
from employees
group by department_id;

/*Write a query to retrieve the first name, last name, and hire date of employees
 hired after January 1, 2021, sorted by hire date in ascending order.J*/
select first_name,last_name,hire_date
from employees
where hire_date > '2021-01-01'
order by hire_date asc;


select  e.first_name,e.last_name, e.email, d.department_name
from employee e 
inner join departments d on e.department_id = d.department_id;

/* Write a query to find the employee with the highest salary. */

select first_name,last_name, salary
from employees
where salary = (select max(salary) from employees);

/* Write a query to update the salary of an employee with the last name "td" to 65000.00 */
update employees
set salary = 65000.00
where last_name = 'td';

/* Write a query to find the average salary of employees hired in 2020.*/
select avg(salary) as avrage_salary_2020
from employees
where year(hire_date)=2020;

/*Write a query to retrieve the names and email addresses of all employees
 whose last names start with the letter 'B'.*/
select first_name,last_name,email
from employees 
where last_name like 'B%'; 

/*Write a query to find the department with the highest average salary among its employees.*/
select department_id, avg(salary) as avrage_salary
from employees
group by department_id
order by avrage_salary desc limit 1;


/*Write a query to retrieve the first name, last name, and hire date of the top 3 employees
 with the highest salaries, sorted by hire date in descending order.*/
select first_name,last_name, hire_date
from employees
order by salary desc, hire_date desc
limit 3;


select e.first_name, e.last_name, e.email, d.department_name
from employees e
inner join departments d ON e.department_id = d.department_id
where e.salary > (
    select avg(salary)
    from employees
    where department_id = e.department_id
);

/*Write a query to find the employee with the highest salary who is not in the 'Sales' department.*/
select first_name, last_name, email, salary 
from employees
where department_id <>(select departments_name ="sales") 
order by salary desc limit 1 ;